from django.apps import AppConfig


class CoursemanagementConfig(AppConfig):
    name = 'coursemanagement'
